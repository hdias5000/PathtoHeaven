package com.example.jay1805.itproject.Chat;

public class ChatObject {

    private String chatId;

    public ChatObject(String chatId) {
        this.chatId = chatId;
    }

    public String getChatId() {
        return chatId;
    }
}
